package com.muipanel;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;

public class MuiPlugin extends JavaPlugin implements CommandExecutor, Listener {

   private static final HashMap < UUID, Integer > playerFlightMode = new HashMap < > ();
   private static boolean isChatFilterEnabled = true;

   @Override
   public void onEnable() {
      this.getCommand("mui").setExecutor(this);
      getServer().getPluginManager().registerEvents(this, this);
      getLogger().info("Ectasy Panel Module successfully injected!");
   }

   @Override
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("Only players can open the visual GUI dashboard!");
         return true;
      }
      openMainMenu((Player) sender);
      return true;
   }

   private void openMainMenu(Player player) {
      Inventory menu = Bukkit.createInventory(null, 27, "§8⚡ §4§lECTASY MAIN MENU §8⚡");
      fillBackground(menu, 27);

      menu.setItem(10, createGuiItem(Material.FEATHER, "§b§lMOVEMENT", "§7Configure Fly, Speed, and NoFall options."));
      menu.setItem(11, createGuiItem(Material.DIAMOND_SWORD, "§c§lCOMBAT", "§7Utilities for targets and entities."));
      menu.setItem(12, createGuiItem(Material.COMMAND_BLOCK, "§e§lMISC / PLAYER", "§7ItemGenerator, KillPots, and Tracking."));
      menu.setItem(13, createGuiItem(Material.GRASS_BLOCK, "§a§lWORLD", "§7Time, weather, and world setups."));
      menu.setItem(14, createGuiItem(Material.WRITABLE_BOOK, "§d§lRENDER / CHAT", "§7Bypass Chat filters cleanly."));

      player.openInventory(menu);
   }

   private void openMovementMenu(Player player) {
      Inventory movement = Bukkit.createInventory(null, 54, "§8⚡ §b§lECTASY: MOVEMENT §8⚡");
      fillBackground(movement, 54);

      movement.setItem(10, createGuiItem(Material.FEATHER, "§a§lMode: §fNormal Fly", "§7Standard survival hover flight.", "§e▶ Click to Select"));
      movement.setItem(19, createGuiItem(Material.GRASS_BLOCK, "§d§lMode: §fCreative Fly", "§7Vanilla style creative flight.", "§e▶ Click to Select"));
      movement.setItem(28, createGuiItem(Material.PHANTOM_MEMBRANE, "§b§lMode: §fMotion Fly", "§7Custom glide physics + slow falling.", "§fHold Crouch to fall faster", "§e▶ Click to Select"));
      movement.setItem(37, createGuiItem(Material.BLAZE_POWDER, "§c§lMode: §fBlatant Fly", "§7Blazing fast standard flight speed (8x).", "§e▶ Click to Select"));

      movement.setItem(22, createGuiItem(Material.DIAMOND_BOOTS, "§3§lPassive: §fNoFall Status", "§7Cancels all fall damage triggers.", "§a§lALWAYS ENGAGED ON FLIGHT"));
      movement.setItem(49, createGuiItem(Material.BARRIER, "§c§l◀ BACK TO MAIN MENU", "§7Return to the main module list."));

      player.openInventory(movement);
   }

   private void openMiscMenu(Player player) {
      Inventory misc = Bukkit.createInventory(null, 54, "§8⚡ §e§lECTASY: MISC §8⚡");
      fillBackground(misc, 54);

      misc.setItem(10, createGuiItem(Material.SPLASH_POTION, "§d§lSpawn: §fKillPot 125", "§7Gives an Instant Health level 125 splash potion.", "§7Instantly deletes health loop calculations.", "§e▶ Click to Spawn"));
      misc.setItem(12, createGuiItem(Material.NETHER_STAR, "§6§lUtility: §fItemGenerator", "§7Spawn extreme base items directly."));
      misc.setItem(14, createGuiItem(Material.BOOK, "§b§lUtility: §fPacketLogger", "§7Logs standard connection payloads."));

      misc.setItem(49, createGuiItem(Material.BARRIER, "§c§l◀ BACK TO MAIN MENU", "§7Return to the main module list."));

      player.openInventory(misc);
   }

   private void openRenderMenu(Player player) {
      Inventory render = Bukkit.createInventory(null, 27, "§8⚡ §d§lECTASY: RENDER & CHAT §8⚡");
      fillBackground(render, 27);

      String status = isChatFilterEnabled ? "§aENABLED" : "§cDISABLED";
      render.setItem(13, createGuiItem(Material.CHAT_SIGN, "§d§lModule: §fChatFilter", "§7Cleanly strips out bad words before broadcasting.", "§7Allows bypasses without flagging logs.", "§7Current State: " + status, "§e▶ Click to Toggle"));

      render.setItem(22, createGuiItem(Material.BARRIER, "§c§l◀ BACK TO MAIN MENU", "§7Return to the main module list."));
      player.openInventory(render);
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      String title = event.getView().getTitle();
      if (!title.contains("ECTASY")) return;

      event.setCancelled(true);
      if (event.getCurrentItem() == null) return;

      Player player = (Player) event.getWhoClicked();
      int slot = event.getRawSlot();

      if (title.contains("MAIN MENU")) {
         if (slot == 10) openMovementMenu(player);
         else if (slot == 12) openMiscMenu(player);
         else if (slot == 14) openRenderMenu(player);
      } else if (title.contains("MOVEMENT")) {
         if (slot == 49) openMainMenu(player);
         else if (slot == 10) applyFlightState(player, 1);
         else if (slot == 19) applyFlightState(player, 2);
         else if (slot == 28) applyFlightState(player, 3);
         else if (slot == 37) applyFlightState(player, 4);
      } else if (title.contains("MISC")) {
         if (slot == 49) openMainMenu(player);
         else if (slot == 10) {
            ItemStack killPot = new ItemStack(Material.SPLASH_POTION);
            PotionMeta meta = (PotionMeta) killPot.getItemMeta();
            meta.setDisplayName("§d§lEctasy Kill Potion");
            meta.addCustomEffect(new PotionEffect(PotionEffectType.INSTANT_HEALTH, 2000, 124, false, true), true);
            killPot.setItemMeta(meta);
            player.getInventory().addItem(killPot);
            player.sendMessage("§d[Ectasy] KillPot spawned into your layout.");
         }
      } else if (title.contains("RENDER")) {
         if (slot == 22) openMainMenu(player);
         else if (slot == 13) {
            isChatFilterEnabled = !isChatFilterEnabled;
            openRenderMenu(player);
         }
      }
   }

   private void applyFlightState(Player player, int mode) {
      UUID uuid = player.getUniqueId();

      player.setAllowFlight(false);
      player.setFlying(false);
      player.setFlySpeed(0.1 f);

      switch (mode) {
      case 1:
         player.setAllowFlight(true);
         player.setFlying(true);
         player.sendMessage("§e[Ectasy] Flight: §aNormal Active");
         break;
      case 2:
         player.setGameMode(GameMode.CREATIVE);
         player.sendMessage("§e[Ectasy] Flight: §dCreative Mode Swapped");
         break;
      case 3:
         player.sendMessage("§e[Ectasy] Flight: §bMotion Slow-Fall Active");
         break;
      case 4:
         player.setAllowFlight(true);
         player.setFlying(true);
         player.setFlySpeed(0.8 f);
         player.sendMessage("§e[Ectasy] Flight: §cBlatant Active (Max Speed)");
         break;
      }
      playerFlightMode.put(uuid, mode);
      player.closeInventory();
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();

      if (!playerFlightMode.containsKey(uuid) || playerFlightMode.get(uuid) != 3) return;

      if (player.getVelocity().getY() < 0 && !player.getLocation().subtract(0, 0.1, 0).getBlock().getType().isSolid()) {
         double dropSpeed = player.isSneaking() ? -0.4 : -0.05;
         Vector lookDirection = player.getLocation().getDirection().setY(0).normalize().multiply(0.35);
         player.setVelocity(new Vector(lookDirection.getX(), dropSpeed, lookDirection.getZ()));
      }
   }

   @EventHandler
   public void onFallDamage(EntityDamageEvent event) {
      if (!(event.getEntity() instanceof Player)) return;
      Player player = (Player) event.getEntity();
      UUID uuid = player.getUniqueId();

      if (playerFlightMode.containsKey(uuid) && playerFlightMode.get(uuid) > 0) {
         if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      if (!isChatFilterEnabled) return;

      String text = event.getMessage();
      String[] filters = {
         "badword1",
         "badword2"
      };
      for (String word: filters) {
         text = text.replaceAll("(?i)" + word, "");
      }
      event.setMessage(text);
   }

   private void fillBackground(Inventory inv, int size) {
      ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
      ItemMeta meta = filler.getItemMeta();
      meta.setDisplayName(" ");
      filler.setItemMeta(meta);
      for (int i = 0; i < size; i++) {
         if (inv.getItem(i) == null) {
            inv.setItem(i, filler);
         }
      }
   }

   private ItemStack createGuiItem(Material material, String name, String...lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      meta.setDisplayName(name);
      meta.setLore(Arrays.asList(lore));
      item.setItemMeta(meta);
      return item;
   }
}